from flask import Flask, render_template, jsonify, request
import cx_Oracle  # Oracle DB 연결을 위한 cx_Oracle 모듈을 가져옵니다
from myDB import getPatientData, getMedical_departmentData, getdoctorData, getwardData, getnurseData, getclinicData, getchartData, getHospitalizationData, searchName, searchBirthday, searchPhone, searchAddress, searchGender

# Oracle 데이터베이스 연결 구성
oracle_username = 'system'
oracle_password = '0000'
oracle_dsn = 'localhost'  # Oracle의 DSN (데이터 소스 이름)

app = Flask(__name__)

# Oracle 데이터베이스 연결을 얻기 위한 함수
def get_oracle_connection():
    connection = cx_Oracle.connect(oracle_username, oracle_password, oracle_dsn)
    return connection

def getPatientData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = """
        SELECT * FROM patient order by patient_id
    """
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'name': row[1],
            'resident_num': row[2],
            'birthday': row[3],
            'phone': row[4],
            'address': row[5],
            'gender': row[6]
        }
        data_list.append(data)

    sql = """
        select medical_treatment_details, clinic_data from clinic where patient_id = any(select patient_id from patient)
    """
    cursor.execute(sql)
    rows = cursor.fetchall()
    

    for i in range(len(rows)):
        data = {
            'clinic_treatment': rows[i][0],
            'clinic_date': rows[i][1]
        }
        data_list[i].update(data)

    cursor.close()
    connection.close()

    return data_list

def getMedical_departmentData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM medical_department"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'name': row[1],
            'phone': row[2]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getdoctorData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM doctor"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'name': row[1],
            'resident_num': row[2],
            'phone': row[3],
            'address': row[4],
            'medical_department_id': row[5]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getwardData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM ward"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'medical_department_id': row[1],
            'phone': row[2]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getnurseData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM nurse"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'medical_department_id': row[1],
            'resident_num': row[2],
            'phone': row[3],
            'address': row[4],
            'medical_department_id': row[5],
            'ward_id' : row[6]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getclinicData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM clinic"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'medical_department_details': row[1],
            'date': row[2],
            'patien_id': row[3],
            'doctor_id': row[4]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getchartData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM chart"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'chart_contents': row[1],
            'clinic_id': row[2],
            'patien_id': row[3]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getHospitalizationData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM Hospitalization"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'date': row[1],
            'day_of_date': row[2],
            'medical_department_id': row[3],
            'ward_id' : row[4],
            'patient_id' : row[5],
            'nurse_id' : row[6],
            'doctor_id' : row[7]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

@app.route('/')
def home():
    data_list = getPatientData()
    return render_template('index.html', data_list=data_list)

# 이 함수를 Oracle 쿼리를 사용하도록 업데이트하세요
@app.route('/search_total', methods=['get', 'post'])
def search_total():
    # connection = get_oracle_connection()
    # cursor = connection.cursor()
    # # 다음 쿼리를 실제 Oracle 쿼리로 바꿔주세요
    # cursor.execute("SELECT * FROM patient")
    # data_list = cursor.fetchall()
    # cursor.close()
    # connection.close()
    data_list = getPatientData()
    return jsonify(data_list)

@app.route('/search_name', methods=['get', 'post'])
def search_name():
    data = request.get_json()
    search_word = data['search_word']
    data_list = searchName(search_word)
    return jsonify(data_list)


@app.route('/search_birthday', methods=['get', 'post'])
def search_birthday():
    data = request.get_json()
    search_word = data['search_word']
    data_list = searchBirthday(search_word)
    return jsonify(data_list)

@app.route('/search_phone', methods=['get', 'post'])
def search_phone():
    data = request.get_json()
    search_word = data['search_word']
    data_list = searchPhone(search_word)
    return jsonify(data_list)

@app.route('/search_address', methods=['get', 'post'])
def search_address():
    data = request.get_json()
    search_word = data['search_word']
    data_list = searchAddress(search_word)
    return jsonify(data_list)

@app.route('/search_gender', methods=['get', 'post'])
def search_gender():
    data = request.get_json()
    search_word = data['search_word']
    data_list = searchGender(search_word)
    return jsonify(data_list)

@app.route('/get_patient_data', methods=['GET'])
def get_patient_data():
    data_list = getPatientData()
    return jsonify(data_list)

if __name__ == '__main__':
    app.run(debug=True)