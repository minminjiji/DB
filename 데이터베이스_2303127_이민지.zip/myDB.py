import cx_Oracle

# Oracle 데이터베이스 연결 구성
oracle_username = 'system'
oracle_password = '0000'
oracle_dsn = 'localhost'  # Oracle의 DSN (데이터 소스 이름)

def get_oracle_connection():
    connection = cx_Oracle.connect(oracle_username, oracle_password, oracle_dsn)
    return connection

def getPatientData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = """
        SELECT * FROM patient
    """
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'name': row[1],
            'resident_num': row[2],
            'birthday': row[3],
            'phone': row[4],
            'address': row[5],
            'gender': row[6]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getMedical_departmentData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM medical_department"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'name': row[1],
            'phone': row[2]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getdoctorData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM doctor"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'name': row[1],
            'resident_num': row[2],
            'phone': row[3],
            'address': row[4],
            'medical_department_id': row[5]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getwardData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM ward"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'medical_department_id': row[1],
            'phone': row[2]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getnurseData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM nurse"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'medical_department_id': row[1],
            'resident_num': row[2],
            'phone': row[3],
            'address': row[4],
            'medical_department_id': row[5],
            'ward_id' : row[6]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getclinicData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM clinic"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'medical_department_details': row[1],
            'date': row[2],
            'patien_id': row[3],
            'doctor_id': row[4]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getchartData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM chart"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'chart_contents': row[1],
            'clinic_id': row[2],
            'patien_id': row[3]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def getHospitalizationData():
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM Hospitalization"
    cursor.execute(sql)
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'date': row[1],
            'day_of_date': row[2],
            'medical_department_id': row[3],
            'ward_id' : row[4],
            'patient_id' : row[5],
            'nurse_id' : row[6],
            'doctor_id' : row[7]
        }
        data_list.append(data)

    cursor.close()
    connection.close()

    return data_list

def searchName(search_word):
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = """
        SELECT * FROM patient WHERE name = :search_word
    """
    cursor.execute(sql, {'search_word': search_word})
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'name': row[1],
            'resident_num': row[2],
            'birthday': row[3],
            'phone': row[4],
            'address': row[5],
            'gender': row[6]
        }
        data_list.append(data)

    sql = """
        select medical_treatment_details, clinic_data from clinic where patient_id = any( SELECT patient_id FROM patient WHERE name = :search_word)
    """
    cursor.execute(sql, {'search_word': search_word})
    rows = cursor.fetchall()

    for i in range(len(rows)):
        data = {
            'clinic_treatment': rows[i][0],
            'clinic_date': rows[i][1]
        }
        data_list[i].update(data)

    cursor.close()
    connection.close()

    return data_list

def searchBirthday(search_word):
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = """
        SELECT * FROM patient WHERE birth = :search_word
    """
    cursor.execute(sql, {'search_word': search_word})
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'name': row[1],
            'resident_num': row[2],
            'birthday': row[3],
            'phone': row[4],
            'address': row[5],
            'gender': row[6]
        }
        data_list.append(data)

    sql = """
        select medical_treatment_details, clinic_data from clinic where patient_id = any( SELECT patient_id FROM patient WHERE birth = :search_word)
    """
    cursor.execute(sql, {'search_word': search_word})
    rows = cursor.fetchall()
    

    for i in range(len(rows)):
        data = {
            'clinic_treatment': rows[i][0],
            'clinic_date': rows[i][1]
        }
        data_list[i].update(data)

    cursor.close()
    connection.close()

    return data_list

def searchPhone(search_word):
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = """
        SELECT * FROM patient WHERE phone = :search_word
    """
    cursor.execute(sql, {'search_word': search_word})
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'name': row[1],
            'resident_num': row[2],
            'birthday': row[3],
            'phone': row[4],
            'address': row[5],
            'gender': row[6]
        }
        data_list.append(data)

    sql = """
        select medical_treatment_details, clinic_data from clinic where patient_id = any( SELECT patient_id FROM patient WHERE phone = :search_word)
    """
    cursor.execute(sql, {'search_word': search_word})
    rows = cursor.fetchall()
    

    for i in range(len(rows)):
        data = {
            'clinic_treatment': rows[i][0],
            'clinic_date': rows[i][1]
        }
        data_list[i].update(data)

    cursor.close()
    connection.close()

    return data_list

def searchAddress(search_word):
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = """
        SELECT * FROM patient WHERE address = :search_word
    """
    cursor.execute(sql, {'search_word': search_word})
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'name': row[1],
            'resident_num': row[2],
            'birthday': row[3],
            'phone': row[4],
            'address': row[5],
            'gender': row[6]
        }
        data_list.append(data)

    sql = """
        select medical_treatment_details, clinic_data from clinic where patient_id = any( SELECT patient_id FROM patient WHERE address = :search_word)
    """
    cursor.execute(sql, {'search_word': search_word})
    rows = cursor.fetchall()
    

    for i in range(len(rows)):
        data = {
            'clinic_treatment': rows[i][0],
            'clinic_date': rows[i][1]
        }
        data_list[i].update(data)

    cursor.close()
    connection.close()

    return data_list

def searchGender(search_word):
    connection = get_oracle_connection()
    cursor = connection.cursor()

    sql = """
        SELECT * FROM patient WHERE gender = :search_word
    """
    cursor.execute(sql, {'search_word': search_word})
    rows = cursor.fetchall()

    data_list = []
    for row in rows:
        data = {
            'num': row[0],
            'name': row[1],
            'resident_num': row[2],
            'birthday': row[3],
            'phone': row[4],
            'address': row[5],
            'gender': row[6]
        }
        data_list.append(data)

    sql = """
        select medical_treatment_details, clinic_data from clinic where patient_id = any( SELECT patient_id FROM patient WHERE gender = :search_word)
    """
    cursor.execute(sql, {'search_word': search_word})
    rows = cursor.fetchall()
    

    for i in range(len(rows)):
        data = {
            'clinic_treatment': rows[i][0],
            'clinic_date': rows[i][1]
        }
        data_list[i].update(data)

    cursor.close()
    connection.close()

    return data_list
