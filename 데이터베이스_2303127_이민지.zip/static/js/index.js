function search() {
    var search_option = $('#search_option').val();
    var search_word = $('#search_box').val();
    
    let postdata = {
        search_word: search_word,
    };
    let keyMap = {
        "patient": ["num", "name", "resident_num", "birthday", "phone", "address", "gender"],
        "medical_department": ["id", "name", "phone"],
        "doctor": ["num", "name", "resident_num", "phone", "address", "medical_department_id"],
        "ward": ["num", "medical_department_id", "phone"],
        "nurse": ["num", "medical_department_id", "resident_num", "phone", "address", "medical_department_id", "ward_id"],
        "clinic": ["num", "medical_department_details", "date", "patient_id", "doctor_id"],
        "chart": ["num", "chart_contents", "clinic_id", "patient_id"],
        "hospitalization": ["num", "date", "day_of_date", "medical_department_id", "ward_id", "patient_id", "nurse_id", "doctor_id"]
    };

    if (search_word == "" && search_option != "total") {
        alert("검색어를 입력해주세요.");
    } else {
        if (search_option == "total") {
            //전송 설정
            $.ajax({
                type: 'POST',
                url: '/search_' + search_option,
                contentType: 'application/json',
                data: JSON.stringify({
                    'search_word': search_word
                }),
                success: function(result) {
                    $('#table_body').empty();
                    for (var i = 0; i < result.length; i++) {
                        var row = '<tr>' +
                            '<td>' + result[i]['num'] + '</td>' +
                            '<td>' + result[i]['name'] + '</td>' +
                            '<td>' + result[i]['resident_num'] + '</td>' +
                            '<td>' + result[i]['birthday'] + '</td>' +
                            '<td>' + result[i]['phone'] + '</td>' +
                            '<td>' + result[i]['address'] + '</td>' +
                            '<td>' + result[i]['gender'] + '</td>' +
                            '<td>' + result[i]['clinic_treatment'] + '</td>' +
                            '<td>' + result[i]['clinic_date'] + '</td>' +
                            '</tr>';
                        $('#table_body').append(row);
                    }
                },
                error: function(error) {
                    console.log(error);
                }
            });
        }
        if (search_option == "name") {
            //전송 설정
            $.ajax({
                type: "POST",
                url: "/search_name",
                contentType: 'application/json',
                data: JSON.stringify({
                    'search_word': search_word
                }),
                success: function(result) {
                    $('#table_body').empty();
                    for (var i = 0; i < result.length; i++) {
                        var row = '<tr>' +
                            '<td>' + result[i]['num'] + '</td>' +
                            '<td>' + result[i]['name'] + '</td>' +
                            '<td>' + result[i]['resident_num'] + '</td>' +
                            '<td>' + result[i]['birthday'] + '</td>' +
                            '<td>' + result[i]['phone'] + '</td>' +
                            '<td>' + result[i]['address'] + '</td>' +
                            '<td>' + result[i]['gender'] + '</td>' +
                            '<td>' + result[i]['clinic_treatment'] + '</td>' +
                            '<td>' + result[i]['clinic_date'] + '</td>' +
                            '</tr>';
                        $('#table_body').append(row);
                    }
                },
                error: function(error) {
                    console.log(error);
                }
            });
        }
        if (search_option == "birthday") {
            //전송 설정
            $.ajax({
                type: "POST",
                url: "/search_birthday",
                contentType: 'application/json',
                data: JSON.stringify({
                    'search_word': search_word
                }),
                success: function(result) {
                    $('#table_body').empty();
                    for (var i = 0; i < result.length; i++) {
                        var row = '<tr>' +
                            '<td>' + result[i]['num'] + '</td>' +
                            '<td>' + result[i]['name'] + '</td>' +
                            '<td>' + result[i]['resident_num'] + '</td>' +
                            '<td>' + result[i]['birthday'] + '</td>' +
                            '<td>' + result[i]['phone'] + '</td>' +
                            '<td>' + result[i]['address'] + '</td>' +
                            '<td>' + result[i]['gender'] + '</td>' +
                            '<td>' + result[i]['clinic_treatment'] + '</td>' +
                            '<td>' + result[i]['clinic_date'] + '</td>' +
                            '</tr>';
                        $('#table_body').append(row);
                    }
                },
                error: function(error) {
                    console.log(error);
                }
            });
        }
        if (search_option == "phone") {
            //전송 설정
            $.ajax({
                type: "POST",
                url: "/search_phone",
                contentType: 'application/json',
                data: JSON.stringify({
                    'search_word': search_word
                }),
                success: function(result) {
                    $('#table_body').empty();
                    for (var i = 0; i < result.length; i++) {
                        var row = '<tr>' +
                            '<td>' + result[i]['num'] + '</td>' +
                            '<td>' + result[i]['name'] + '</td>' +
                            '<td>' + result[i]['resident_num'] + '</td>' +
                            '<td>' + result[i]['birthday'] + '</td>' +
                            '<td>' + result[i]['phone'] + '</td>' +
                            '<td>' + result[i]['address'] + '</td>' +
                            '<td>' + result[i]['gender'] + '</td>' +
                            '<td>' + result[i]['clinic_treatment'] + '</td>' +
                            '<td>' + result[i]['clinic_date'] + '</td>' +
                            '</tr>';
                        $('#table_body').append(row);
                    }
                },
                error: function(error) {
                    console.log(error);
                }
            });
        }
        if (search_option == "address") {
            //전송 설정
            $.ajax({
                type: "POST",
                url: "/search_address",
                contentType: 'application/json',
                data: JSON.stringify({
                    'search_word': search_word
                }),
                success: function(result) {
                    $('#table_body').empty();
                    for (var i = 0; i < result.length; i++) {
                        var row = '<tr>' +
                            '<td>' + result[i]['num'] + '</td>' +
                            '<td>' + result[i]['name'] + '</td>' +
                            '<td>' + result[i]['resident_num'] + '</td>' +
                            '<td>' + result[i]['birthday'] + '</td>' +
                            '<td>' + result[i]['phone'] + '</td>' +
                            '<td>' + result[i]['address'] + '</td>' +
                            '<td>' + result[i]['gender'] + '</td>' +
                            '<td>' + result[i]['clinic_treatment'] + '</td>' +
                            '<td>' + result[i]['clinic_date'] + '</td>' +
                            '</tr>';
                        $('#table_body').append(row);
                    }
                },
                error: function(error) {
                    console.log(error);
                }
            });
        }
        if (search_option == "gender") {
            if (search_word !== "여" && search_word !== "남") {
                alert("'여' 또는 '남'으로 입력해주세요.");
            } else {
                //전송 설정
                $.ajax({
                    type: "POST",
                    url: "/search_gender",
                    contentType: 'application/json',
                    data: JSON.stringify({
                        'search_word': search_word
                    }),
                    success: function(result) {
                        $('#table_body').empty();
                        for (var i = 0; i < result.length; i++) {
                            var row = '<tr>' +
                                '<td>' + result[i]['num'] + '</td>' +
                                '<td>' + result[i]['name'] + '</td>' +
                                '<td>' + result[i]['resident_num'] + '</td>' +
                                '<td>' + result[i]['birthday'] + '</td>' +
                                '<td>' + result[i]['phone'] + '</td>' +
                                '<td>' + result[i]['address'] + '</td>' +
                                '<td>' + result[i]['gender'] + '</td>' +
                                '<td>' + result[i]['clinic_treatment'] + '</td>' +
                                '<td>' + result[i]['clinic_date'] + '</td>' +
                                '</tr>';
                            $('#table_body').append(row);
                        }
                    },
                    error: function(error) {
                        console.log(error);
                    }   
                });
            }
        }
    }
}
